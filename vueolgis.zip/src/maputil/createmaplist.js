import Map from 'ol/Map';
import View from 'ol/View';
import TileLayer from 'ol/layer/Tile';
import XYZ from 'ol/source/XYZ'
// terget,view,{type,}
let defaultmap = function (...other){
  this.other = other
}

export let maplist = defaultmap
