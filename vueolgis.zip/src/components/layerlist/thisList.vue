<template>
  <ul class="vector-list"  >
    这是实时图层
  </ul>
</template>

<script>

export default {
  name:'vectorLayerList',
  data(){
    return{

    }
  },
  methods:{

  }
}
</script>

<style scoped>
.base-map-list{
  display: flex;
  list-style: none;
  width: 390px;
  flex-wrap:wrap;
  color: #3e3e3e;
}
</style>

