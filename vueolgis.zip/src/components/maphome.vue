<template>
  <div class="maphome">
    <div class="mapview" tabindex="0" id="mapdiv" ref='mapdiv' ></div>
    <!--这里是图层切换、图层控制按钮组件 -->
    <div class="layersList" @mouseleave.stop.self="whichList=''" >
      <div @mouseenter.stop.self="whichList='baseMapList'" :class="['layersListDiv',whichList=='baseMapList'? 'layersListDivIs':'']" id='baseMapList' >底图切换</div>
      <div @mouseenter.stop.self="whichList='2'" :class="['layersListDiv',whichList==2? 'layersListDivIs':'']" id="layerList"   >图层控制</div>
      <div @mouseenter.stop.self="whichList='3'" :class="['layersListDiv',whichList==3? 'layersListDivIs':'']" id="tameList"    >实时数据</div>
        <keep-alive>
          <component 
          :is="whichList"
          v-if="!(whichList!=='baseMapList')"
          class="layersListPopup"></component>
        </keep-alive>
    </div>
  </div>
</template>

<script>
//功能组件
import * as layersConfig from '../../static/mapconfig/layersConfig';
import { maplist } from '@/maputil/createmaplist.js'
//页面组件
import baseMapList from "@/components/layerlist/baseMapList"

import Map from 'ol/Map';
import View from 'ol/View';
import TileLayer from 'ol/layer/Tile';
import XYZ from 'ol/source/XYZ';
export default {
  name: 'HelloWorld',
  data () {
    return {
      whichList:''
    }
  },
  components:{
    baseMapList
  },
  mounted(){
    //创建的时候将图层配置打入全局变量
    this.$root.layersConfig = layersConfig
    this.initTDT([117.16, 38.75]);
    let aabbb = new maplist('123','sdfsg')
    console.log(aabbb.other)
  },
  methods:{
    initTDT:function(centerpint){
      this.$root.map = new Map({
        target: this.$refs.mapdiv,
        layers: [
          new TileLayer({
            source: new XYZ({
              url: "http://t2.tianditu.com/DataServer?T=vec_w&x={x}&y={y}&l={z}"
            }),
            name: "天地图电子地图",
            type: "BaseMap"
          }),
          new TileLayer({
            source: new XYZ({
              url: 'http://t3.tianditu.com/DataServer?T=img_w&x={x}&y={y}&l={z}'
            }),
            visible:false,
            isGroup: true,
            name: "天地图影像地图",
            type: "BaseMap"
          }),  
          new TileLayer({
            source: new XYZ({
              url: "http://t2.tianditu.com/DataServer?T=cva_w&x={x}&y={y}&l={z}"
            }),
            isGroup: true,
            name: "天地图文字标注"
          })       
        ],
        view: new View({
          projection: "EPSG:4326",
          center: [117.395, 38.93],
          zoom: 14,
          minZoom:6,
          maxZoom:16
        })
      });
    },
  }
}
</script>

<style scoped>
.maphome,.mapview{
  height: 100%;
  width: 100%;
}
.mapview{
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
}
.layersList{
  width: 24%;
  margin-left: 29.16667%;
  left: 40%;
  top: 1%;
  position: relative;
  z-index: 2;
  /* top: -100%; */
  box-sizing: border-box;
  float: left;
  display: flex;
  flex-wrap: wrap;
  justify-content:space-between;
  align-items: center;
}
.layersListDiv{
  padding: 5px 1px;
  display: inline-block;
  flex-basis: 32%;
  margin: 0 auto;
  background-image: linear-gradient(#e0e0e0, #bbb);
  border: 1px solid rgba(0,0,0,.2);
  border-radius: .5em;
  box-shadow: 0 1px white inset;
  text-align: center;
  text-shadow: 0 1px 1px #85a2f761;
  color: #333333b8;
  font-weight: 200;
  font-size: 15px;
  cursor: pointer;
}
.layersListDivIs{
  background-image: linear-gradient(#a8a8a8, #bbb);
}
.layersListPopup{
  display: inline-flex;
  flex-basis: 99%;
  margin-top: 1px;
  padding: 10px;
  background: white;
  border: 1px solid rgba(0, 0, 0, 0.19);
  border-radius: 0.5em;
  box-shadow: 0px 1px 2px 0px #73737382;
}
</style>
